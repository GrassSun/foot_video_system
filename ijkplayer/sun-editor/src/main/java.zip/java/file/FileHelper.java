package file;

import android.content.Context;
import android.os.Environment;

import com.github.hiteshsondhi88.libffmpeg.ExecuteBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.LoadBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegCommandAlreadyRunningException;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegNotSupportedException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Array;
import java.util.ArrayList;

import markoperator.MarkMatch;
import markoperator.MarkSegment;
import markoperator.MarkSubTitle;

/**
 * Created by sunweijun on 18-3-13.
 */

public class FileHelper {
    private Context mContext = null;
    private FileHelper(Context _context) {
        mContext = _context;
    }

    static FileHelper mFileHelper = null;

    public synchronized static FileHelper getInstance(Context mContext) {
        if(mFileHelper == null)
            mFileHelper = new FileHelper(mContext);
        return mFileHelper;
    }

    public File getSDcard() {
        return Environment.getExternalStorageDirectory();
    }

    public File getFilesDir() {
        return mContext.getFilesDir();
    }

    public File getCacheDir() {
        return mContext.getCacheDir();
    }

    public void getMediaSegment(String video, float start, float duration) {

        FFmpeg ffmpeg = FFmpeg.getInstance(mContext);
        try {
            ffmpeg.loadBinary(new LoadBinaryResponseHandler() {

                @Override
                public void onStart() {}
                @Override
                public void onFailure() {}
                @Override
                public void onSuccess() {}
            });
        } catch (FFmpegNotSupportedException e) {
            e.printStackTrace();
        }

        String testPath = getSDcard().getAbsolutePath()+"/videoCache";
        File testDir = new File(testPath);
        testDir.mkdirs();

        try {
            // to execute "ffmpeg -version" command you just need to pass "-version"
            String ss = String.valueOf(start);
            String tt = String.valueOf(duration);
            String cmd = "-ss " + ss + " "
                    + "-t " + tt + " "
                    + "-i " + video + " "
                    + "-vcodec h264 -acodec aac -strict -2 -y "
                    + testPath + "/output.mp4";

            ffmpeg.execute(cmd.split(" "), new ExecuteBinaryResponseHandler() {

                @Override
                public void onStart() {}

                @Override
                public void onProgress(String message) {}

                @Override
                public void onFailure(String message) {}

                @Override
                public void onSuccess(String message) {}

                @Override
                public void onFinish() {}
            });
        } catch (FFmpegCommandAlreadyRunningException e) {
            // Handle if FFmpeg is already running
        }
    }

    public String getFileString(File file) {
        String res = "";
        try {
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line;
            while( (line = br.readLine()) != null)
                res += line + '\n';
            br.close();
            fr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }

    public void removeMatchFile(String title) {
        String path = getMatchDir().getAbsolutePath() + '/' + title + ".json";
        File file = new File(path);
        if(file.exists() && file.isFile()) {
            file.delete();
        }
    }

    public void writeMatchFile(MarkMatch markMatch) {
        String data = markMatch.getString();
        try {
            String path = getMatchDir().getAbsolutePath();
            path += '/' + markMatch.getName() + ".json";
            File file = new File(path);
            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(data);
            bw.close();
            fw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public File getSourceDir() {
        String path = getFilesDir().getAbsolutePath() + "/videoSource";
        File sourceDir = new File(path);
        if(!sourceDir.exists())
            sourceDir.mkdirs();
        return sourceDir;
    }

    public void writeVideoSource(String name, JSONObject json) {
        String path = getSourceDir().getAbsolutePath();
        File file = new File(path + '/' + name + ".txt");
        try {
            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);
            String data = json.toString();
            bw.write(data);
            bw.close();
            fw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<ArrayList<String> > parseVideoSource(String data) {
        ArrayList<ArrayList<String> > res = new ArrayList<>();
        ArrayList<String> north, middle, south;
        north = new ArrayList<>();
        middle = new ArrayList<>();
        south = new ArrayList<>();

        try {
            JSONObject json = new JSONObject(data);
            JSONArray jsonNorth = json.getJSONArray("north");
            JSONArray jsonMiddle = json.getJSONArray("middle");
            JSONArray jsonSouth = json.getJSONArray("south");

            for(int i = 0; i < jsonNorth.length(); ++i)
                north.add(jsonNorth.getString(i));

            for(int i = 0; i < jsonMiddle.length(); ++i)
                middle.add(jsonMiddle.getString(i));

            for(int i = 0; i < jsonSouth.length(); ++i)
                south.add(jsonSouth.getString(i));

        } catch (JSONException e) {
            e.printStackTrace();
        }

        res.add(north);
        res.add(middle);
        res.add(south);
        return res;
    }

    public ArrayList<String> getSourceList() {
        ArrayList<String> res = new ArrayList<>();
        File sourceDir = getSourceDir();
        File[] mList = sourceDir.listFiles();
        for(int i = 0; i < mList.length; ++i) {
            String filename = mList[i].getName();
            int dot = filename.lastIndexOf('.');
            if(dot < 0 || dot >= filename.length())
                continue;
            String text = filename.substring(dot + 1);
            if(!text.equals("txt"))
                continue;
            text = filename.substring(0, dot);
            res.add(text);
        }
        return res;

    }


    public void makeVideoSource() {
        MySimpleTest simpleTest = new MySimpleTest();
        simpleTest.markTestArrayList();

        ArrayList<String> url = simpleTest.getUrlList();

        JSONObject list = new JSONObject();
        JSONArray north = new JSONArray();
        JSONArray south = new JSONArray();
        JSONArray middle = new JSONArray();

        north.put(url.get(2));
        north.put(url.get(3));
        south.put(url.get(3));
        south.put(url.get(2));
        middle.put(url.get(1));

        try {
            list.put("north", north);
            list.put("south", south);
            list.put("middle", middle);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        writeVideoSource("match1", list);

    }

    public void makeTestMarkMatch() {

        makeVideoSource();
        MySimpleTest simpleTest = new MySimpleTest();
        simpleTest.markTestArrayList();
        ArrayList<String> url = simpleTest.getUrlList();
        ArrayList<String> name = simpleTest.getNameList();

        MarkMatch matchTemp;
        matchTemp = new MarkMatch();
        matchTemp.addSegment(new MarkSegment(url.get(1), 1, 3000));
        matchTemp.addSegment(new MarkSegment(url.get(1), 7000, 10000));
        matchTemp.setName("mark1");
        matchTemp.setVideoSource("match1");
        matchTemp.addSubTitle(new MarkSubTitle("text1", 1, 3000));
        matchTemp.addSubTitle(new MarkSubTitle("text2", 3000, 6000));
        writeMatchFile(matchTemp);

        matchTemp = new MarkMatch();
        matchTemp.addSegment(new MarkSegment(url.get(1), 1, 3000));
        matchTemp.addSegment(new MarkSegment(url.get(1), 7000, 10000));
        matchTemp.setVideoSource("match1");
        matchTemp.setName("mark2");
        matchTemp.addSubTitle(new MarkSubTitle("text1", 1, 3000));
        matchTemp.addSubTitle(new MarkSubTitle("text2", 3000, 6000));
        writeMatchFile(matchTemp);
    }

    public File getMatchDir() {
        String path = getFilesDir().getAbsolutePath() + "/match";
        File matchDir = new File(path);
        if(!matchDir.exists())
            matchDir.mkdirs();
        return matchDir;
    }

    public ArrayList<MarkMatch> getMatchList() {
        ArrayList<MarkMatch> mList = new ArrayList<>();

        File matchDir = getMatchDir();

        if(!matchDir.isDirectory())
            return mList;

        File[] fileList = matchDir.listFiles();

        for(int i = 0; i < fileList.length; ++i) {
            String json = getFileString(fileList[i]);
            MarkMatch markMatch;
            try {
                markMatch = new MarkMatch(new JSONObject(json));
            } catch (JSONException e) {
                e.printStackTrace();
                markMatch = new MarkMatch();
            }
            mList.add(markMatch);
        }

        return mList;
    }
}
