package file;

import android.content.Context;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by sunweijun on 18-3-20.
 */

public class MySimpleTest {
    private Context mContext;
    private final String TAG = "SimpleTest";

    public MySimpleTest() {}

    public MySimpleTest(Context _context) {
        mContext = _context;
    }

    private ArrayList<String> urlList;

    private ArrayList<String> nameList;

    public void markTestArrayList() {
        urlList = new ArrayList<>();
        nameList = new ArrayList<>();

        FileHelper fh = FileHelper.getInstance(mContext);

        String test = fh.getSDcard().getAbsolutePath() + "/TEST/test.mp4";
        String test1 = fh.getSDcard().getAbsolutePath() + "/TEST/test1.mp4";
        String test2 = fh.getSDcard().getAbsolutePath() + "/TEST/test2.mp4";

        urlList.add("http://166.111.116.227:8088/flv0");
        nameList.add("flv0");

        urlList.add(test);
        nameList.add("TEST");

        urlList.add(test1);
        nameList.add("TEST1");

        urlList.add(test2);
        nameList.add("TEST2");

        urlList.add("http://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8");
        nameList.add("bipbop basic master playlist");

        urlList.add("http://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/gear1/prog_index.m3u8");
        nameList.add("bipbop basic 400x300 @ 232 kbps");

        urlList.add("http://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/gear2/prog_index.m3u8");
        nameList.add("bipbop basic 640x480 @ 650 kbps");

        urlList.add("http://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/gear3/prog_index.m3u8");
        nameList.add("bipbop basic 640x480 @ 1 Mbps");

        urlList.add("http://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/gear4/prog_index.m3u8");
        nameList.add("bipbop basic 960x720 @ 2 Mbps");

        urlList.add("http://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/gear0/prog_index.m3u8");
        nameList.add("bipbop basic 22.050Hz stereo @ 40 kbps");

        urlList.add("http://devimages.apple.com.edgekey.net/streaming/examples/bipbop_16x9/bipbop_16x9_variant.m3u8");
        nameList.add("bipbop advanced master playlist");

        urlList.add("http://devimages.apple.com.edgekey.net/streaming/examples/bipbop_16x9/gear1/prog_index.m3u8");
        nameList.add("bipbop advanced 416x234 @ 265 kbps");

        urlList.add("http://devimages.apple.com.edgekey.net/streaming/examples/bipbop_16x9/gear2/prog_index.m3u8");
        nameList.add("bipbop advanced 640x360 @ 580 kbps");

        urlList.add("http://devimages.apple.com.edgekey.net/streaming/examples/bipbop_16x9/gear3/prog_index.m3u8");
        nameList.add("bipbop advanced 960x540 @ 910 kbps");

        urlList.add("http://devimages.apple.com.edgekey.net/streaming/examples/bipbop_16x9/gear4/prog_index.m3u8");
        nameList.add("bipbop advanced 1289x720 @ 1 Mbps");

        urlList.add("http://devimages.apple.com.edgekey.net/streaming/examples/bipbop_16x9/gear5/prog_index.m3u8");
        nameList.add("bipbop advanced 1920x1080 @ 2 Mbps");

        urlList.add("http://devimages.apple.com.edgekey.net/streaming/examples/bipbop_16x9/gear0/prog_index.m3u8");
        nameList.add("bipbop advanced 22.050Hz stereo @ 40 kbps");
    }

    public ArrayList<String> getUrlList() {
        return urlList;
    }

    public ArrayList<String> getNameList() {
        return nameList;
    }

    public void simpleTest()
    {
        Log.i(TAG, "BEGIN");
        Log.i(TAG, "-------------------------------------------------");

        FileHelper fileHelper = FileHelper.getInstance(mContext);

        Log.i(TAG, "SD = " + fileHelper.getSDcard().getAbsolutePath());
        Log.i(TAG, "FilesDir = " + fileHelper.getFilesDir().getAbsolutePath());
        Log.i(TAG, "DataDir = " + fileHelper.getCacheDir().getAbsolutePath());

        String video = "http://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/gear4/prog_index.m3u8";
        //fileHelper.getMediaSegment(video, 10.5f, 0.5f);

        Log.i(TAG, "-------------------------------------------------");
        Log.i(TAG, "END");
    }
}
