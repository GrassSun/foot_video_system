package editor.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;

import editor.ijk.demo.R;
import file.FileHelper;
import markoperator.MarkMatch;
import markoperator.MarkSegment;

public class SegmentInputActivity extends AppCompatActivity {

    public static Intent newIntent(Context context, MarkSegment segment) {
        Intent intent = new Intent(context, SegmentInputActivity.class);
        String markString = segment.getJson().toString();
        intent.putExtra("markSegment", markString);
        return intent;
    }

    private MarkSegment markSegment;
    private int sourceIndex = 0;
    private EditText startText;
    private EditText endText;
    private Button cameraButton;
    private Button confirmButton;
    private String videoSource;
    private FileHelper fileHelper;
    private ArrayList<String> sourceList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segment_input);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Demo");
        setSupportActionBar(toolbar);

        Intent intent = getIntent();
        videoSource = intent.getStringExtra("videoSource");
        fileHelper = FileHelper.getInstance(getApplicationContext());
        sourceList = new ArrayList<>();
        File sourceFile = new File(fileHelper.getSourceDir().getAbsolutePath() + "/" + videoSource
                + ".txt");
        String data = fileHelper.getFileString(sourceFile);
        String[] path = data.split("\n");
        for(int i = 0; i < path.length; ++i)
            if(!path[i].equals(""))
                sourceList.add(path[i]);

        startText = (EditText) findViewById(R.id.start_time);
        endText = (EditText) findViewById(R.id.end_time);
        try {
            String markString = intent.getStringExtra("markSegment");
            markSegment = new MarkSegment(new JSONObject(markString));
        } catch (JSONException e) {
            markSegment = new MarkSegment();
        }

        if(!markSegment.getVideoPath().equals("")) {
            startText.setText(String.valueOf(markSegment.getSt() * 0.001));
            endText.setText(String.valueOf(markSegment.getEd() * 0.001));
        }

        cameraButton = (Button) findViewById(R.id.camera_button);
        confirmButton = (Button) findViewById(R.id.confirm_button);

        cameraButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sourceIndex = (sourceIndex + 1) % sourceList.size();
                cameraButton.setText("摄像头" + String.valueOf(sourceIndex + 1));
            }
        });

        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(startText.getText().equals("") || endText.getText().equals("")) {
                    return;
                }
                String videoPath = sourceList.get(sourceIndex);
                long st = (long) (Double.valueOf(startText.getText().toString()) * 1000 + 1);
                long ed = (long) (Double.valueOf(endText.getText().toString())* 1000 + 1);
                MarkSegment segment = new MarkSegment(videoPath, st, ed);
                Intent intent = new Intent();
                intent.putExtra("markSegment", segment.getJson().toString());
                setResult(1001, intent);
                finish();
            }
        });
    }

}
