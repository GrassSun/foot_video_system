package editor.activities;


import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.ViewGroup;
import android.widget.TableLayout;
import android.widget.TextView;

import org.json.JSONObject;

import markoperator.MarkMatch;
import tv.danmaku.ijk.media.player.IjkMediaPlayer;
import tv.danmaku.ijk.media.player.misc.ITrackInfo;
import editor.ijk.demo.R;
import tv.danmaku.ijk.media.example.application.Settings;
import tv.danmaku.ijk.media.example.fragments.TracksFragment;
import tv.danmaku.ijk.media.example.widget.media.AndroidMediaController;

import editor.widget.EditorView;

public class EditorActivity extends AppCompatActivity implements TracksFragment.ITrackHolder {
    private static final String TAG = "EditorActivity";

    private MarkMatch mMarkMatch;
    private String mVideoPath, bgmPath;

    private AndroidMediaController mMediaController;
    private EditorView mVideoView;
    private TextView mToastTextView;
    private TableLayout mHudView;
    private DrawerLayout mDrawerLayout;
    private ViewGroup mRightDrawer;

    private Settings mSettings;
    private boolean mBackPressed;

    public static Intent newIntent(Context context, String markString) {
        Intent intent = new Intent(context, editor.activities.EditorActivity.class);
        intent.putExtra("markMatch", markString);
        return intent;
    }

    public static void intentTo(Context context, MarkMatch markMatch) {
        context.startActivity(newIntent(context, markMatch.getString()));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        mSettings = new Settings(this);

        Intent intent = getIntent();

        // handle arguments
        String markString = intent.getStringExtra("markMatch");
        try {
            mMarkMatch = new MarkMatch(new JSONObject(markString));
        } catch (Exception e) {
            e.printStackTrace();
        }

        if(mMarkMatch.size() == 0)
            finish();
        mVideoPath = mMarkMatch.getSegment(0).getVideoPath();

        // init UI
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Demo");
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        mMediaController = new AndroidMediaController(this, true);
        mMediaController.setSupportActionBar(actionBar);

        mToastTextView = (TextView) findViewById(R.id.toast_text_view);

        mHudView = (TableLayout) findViewById(R.id.hud_view);
        //mHudView.setVisibility(View.INVISIBLE);

/*        mHudView = new TableLayout(getApplicationContext());

        TableLayout.LayoutParams lp = new TableLayout.LayoutParams();
        lp.width=TableLayout.LayoutParams.WRAP_CONTENT;
        lp.height=TableLayout.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        mHudView.setLayoutParams(lp);
        mHudView.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout fl = (FrameLayout) findViewById(R.id.my_frame);
        fl.addView(mHudView);
        mHudView.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        mHudView.setPadding(10, 10, 10, 10);
*/
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mRightDrawer = (ViewGroup) findViewById(R.id.right_drawer);

        mDrawerLayout.setScrimColor(Color.TRANSPARENT);

        // init player
        IjkMediaPlayer.loadLibrariesOnce(null);
        IjkMediaPlayer.native_profileBegin("libijkplayer.so");

        mVideoView = (EditorView) findViewById(R.id.editor_view);
        mVideoView.setMediaController(mMediaController);
        mVideoView.setSubView(mHudView);

        // prefer mVideoPath
        if (mMarkMatch != null)
            mVideoView.setMarkMatch(mMarkMatch);
        else {
            Log.e(TAG, "Null Data Source\n");
            finish();
            return;
        }

        mVideoView.start();
    }

    @Override
    public void onBackPressed() {
        mBackPressed = true;

        super.onBackPressed();
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (mBackPressed || !mVideoView.isBackgroundPlayEnabled()) {
            mVideoView.stopPlayback();
            mVideoView.release(true);
            mVideoView.stopBackgroundPlay();
        } else {
            mVideoView.enterBackground();
        }
        IjkMediaPlayer.native_profileEnd();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        menu.add(1, 0, 0, "media info");
        //getMenuInflater().inflate(R.menu.menu_player, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int group = item.getGroupId();
        int id = item.getItemId();
        if(group == 1) {
            if(id == 0) {
                mVideoView.showMediaInfo();
            }
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public ITrackInfo[] getTrackInfo() {
        if (mVideoView == null)
            return null;

        return mVideoView.getTrackInfo();
    }

    @Override
    public void selectTrack(int stream) {
        mVideoView.selectTrack(stream);
    }

    @Override
    public void deselectTrack(int stream) {
        mVideoView.deselectTrack(stream);
    }

    @Override
    public int getSelectedTrack(int trackType) {
        if (mVideoView == null)
            return -1;

        return mVideoView.getSelectedTrack(trackType);
    }

    public void setSpeed(float speed) {
        mVideoView.setSpeed(speed);
    }
}