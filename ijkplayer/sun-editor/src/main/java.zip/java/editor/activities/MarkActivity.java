package editor.activities;

import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;

import editor.ijk.demo.R;
import editor.widget.ScreenSizeUtils;
import markoperator.MarkMatch;
import markoperator.MarkSegment;
import tv.danmaku.ijk.media.example.application.Settings;
import tv.danmaku.ijk.media.example.fragments.TracksFragment;
import tv.danmaku.ijk.media.example.widget.media.AndroidMediaController;
import tv.danmaku.ijk.media.example.widget.media.IjkVideoView;
import tv.danmaku.ijk.media.example.widget.media.MeasureHelper;
import tv.danmaku.ijk.media.player.IjkMediaPlayer;
import tv.danmaku.ijk.media.player.misc.ITrackInfo;

public class MarkActivity extends AppCompatActivity implements TracksFragment.ITrackHolder {
    private static final String TAG = "MarkActivity";
    public static final int MARK_FINISHED = 1013;
    public static final int MARK_UNFINISHED = 1002;

    private Context mContext;
    private String mVideoPath;
    private String mVideoSource;
    private Uri mVideoUri;
    private MarkMatch markMatch;

    private AndroidMediaController mMediaController;
    private IjkVideoView mVideoView;
    private TextView mToastTextView;
    private TableLayout mHudView;
    private DrawerLayout mDrawerLayout;
    private ViewGroup mRightDrawer;
    private ImageView imageButton;
    private int imageFlag;

    private Settings mSettings;
    private boolean mBackPressed;

    final float[] speedList = {0.5f, 1.0f, 1.5f, 2.0f};


    public static Intent newIntent(Context context, String videoPath, String videoTitle) {
        Intent intent = new Intent(context, MarkActivity.class);
        intent.putExtra("videoPath", videoPath);
        intent.putExtra("videoTitle", videoTitle);
        return intent;
    }

    private Dialog dialog;
    private int segmentStart;
    private int segmentEnd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(MARK_UNFINISHED);
        setContentView(R.layout.activity_mark);

        mContext = getApplicationContext();

        mSettings = new Settings(this);

        Intent intent = getIntent();

        // handle arguments
        mVideoPath = intent.getStringExtra("videoPath");
        mVideoSource= intent.getStringExtra("videoSource");

        String intentAction = intent.getAction();
        if (!TextUtils.isEmpty(intentAction)) {
            if (intentAction.equals(Intent.ACTION_VIEW)) {
                mVideoPath = intent.getDataString();
            } else if (intentAction.equals(Intent.ACTION_SEND)) {
                mVideoUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
                    String scheme = mVideoUri.getScheme();
                    if (TextUtils.isEmpty(scheme)) {
                        Log.e(TAG, "Null unknown scheme\n");
                        finish();
                        return;
                    }
                    if (scheme.equals(ContentResolver.SCHEME_ANDROID_RESOURCE)) {
                        mVideoPath = mVideoUri.getPath();
                    } else if (scheme.equals(ContentResolver.SCHEME_CONTENT)) {
                        Log.e(TAG, "Can not resolve content below Android-ICS\n");
                        finish();
                        return;
                    } else {
                        Log.e(TAG, "Unknown scheme " + scheme + "\n");
                        finish();
                        return;
                    }
                }
            }
        }

        // init UI
        Toolbar toolbar = (Toolbar) findViewById(R.id.mark_toolbar);
        toolbar.setTitle("Mark Demo");
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        mMediaController = new AndroidMediaController(this, true);
        mMediaController.setSupportActionBar(actionBar);

        mToastTextView = (TextView) findViewById(R.id.mark_toast_text_view);
        mHudView = (TableLayout) findViewById(R.id.mark_hud_view);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.mark_drawer_layout);
        mRightDrawer = (ViewGroup) findViewById(R.id.mark_right_drawer);

        mDrawerLayout.setScrimColor(Color.TRANSPARENT);

        // init player
        IjkMediaPlayer.loadLibrariesOnce(null);
        IjkMediaPlayer.native_profileBegin("libijkplayer.so");

        imageButton = (ImageView) findViewById(R.id.mark_button);
        imageFlag = 0;

        markMatch = new MarkMatch();
        markMatch.setVideoSource(mVideoSource);


        imageButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                imageFlag ^= 1;
                if(imageFlag == 0) {
                    setDialog();
                    imageButton.setImageResource(R.drawable.mark_image);
                    segmentEnd = mVideoView.getCurrentPosition();
                    subtitleEdit.setText("");
                    timeSpin.setSelection(0);
                    speedSpin.setSelection(1);
                    typeSpin.setSelection(0);

                    dialog.show();
                    mVideoView.pause();
                } else {
                    imageButton.setImageResource(R.drawable.mark_image_right);
                    segmentStart = mVideoView.getCurrentPosition();
                }
            }
        });

        mHudView.setVisibility(View.INVISIBLE);

        mVideoView = (IjkVideoView) findViewById(R.id.mark_video_view);
        mVideoView.setMediaController(mMediaController);
        mVideoView.setHudView(mHudView);
        // prefer mVideoPath
        if (mVideoPath != null)
            mVideoView.setVideoPath(mVideoPath);
        else if (mVideoUri != null)
            mVideoView.setVideoURI(mVideoUri);
        else {
            Log.e(TAG, "Null Data Source\n");
            finish();
            return;
        }
        mVideoView.start();
        Snackbar.make(mVideoView, "点击左侧按钮以开始mark片段,再次点击结束mark", Snackbar.LENGTH_LONG).show();
    }

    private Spinner typeSpin;
    private Spinner timeSpin;
    private EditText subtitleEdit;
    private Spinner speedSpin;

    private void setDialog() {
        dialog = new Dialog(this, R.style.NormalDialogStyle);
        View view = View.inflate(this, R.layout.dialog_mark, null);
        dialog.setContentView(view);
        dialog.setCanceledOnTouchOutside(true);
        view.setMinimumHeight((int) (ScreenSizeUtils.getInstance(this).getScreenHeight() * 0.23f));
        Window dialogWindow = dialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        lp.width = (int) (ScreenSizeUtils.getInstance(this).getScreenWidth() * 0.9f);
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.BOTTOM;

        dialog.setCanceledOnTouchOutside(false);

        typeSpin = (Spinner) view.findViewById(R.id.type_spinner);
        timeSpin = (Spinner) view.findViewById(R.id.time_spinner);
        speedSpin = (Spinner) view.findViewById(R.id.speed_spinner);
        subtitleEdit = (EditText) view.findViewById(R.id.mark_subtitle);
        subtitleEdit.setHint("输入字幕");

        Button cancelButton = (Button) view.findViewById(R.id.cancel_button);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                subtitleEdit.setText("");
                dialog.dismiss();
                mVideoView.start();
                Snackbar.make(mVideoView, "mark取消,再次点击按钮以开始mark新片段", Snackbar.LENGTH_LONG).show();
            }
        });

        Button acceptButton = (Button) view.findViewById(R.id.accept_button);
        acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int timePrevious = (timeSpin.getSelectedItemPosition()) * 5000;
                int kind = typeSpin.getSelectedItemPosition();

                if(segmentStart > timePrevious)
                    segmentStart -= timePrevious;
                else segmentStart = 1;

                MarkSegment segment = new MarkSegment(mVideoPath, segmentStart, segmentEnd);
                segment.setValue("subtitle", subtitleEdit.getText().toString());
                segment.setValue("type", String.valueOf(kind));
                markMatch.addSegment(segment);

                dialog.dismiss();
                mVideoView.start();
                Snackbar.make(mVideoView, "mark结束,再次点击按钮以开始mark新片段", Snackbar.LENGTH_LONG).show();
            }
        });

        final String[] timeSelect = {"开头提前0s", "开头提前5s", "开头提前10s", "开头提前15s", "开头提前20s"};
        final String[] typeSelect = {"进球" , "射门", "点球", "任意球", "其它"};
        final String[] speedSelect = {"0.5倍速", "1.0倍速", "1.5倍速", "2.0倍速"};

        ArrayAdapter<String> timeSpinnerAdapter = new ArrayAdapter<String>(this, android.R.layout
                .simple_spinner_item, timeSelect);

        timeSpin.setAdapter(timeSpinnerAdapter);

        ArrayAdapter<String> typeSpinnerAdapter = new ArrayAdapter<String>(this, android.R.layout
                .simple_spinner_item, typeSelect);

        typeSpin.setAdapter(typeSpinnerAdapter);

        ArrayAdapter<String> speedSpinnerAdapter = new ArrayAdapter<String>(this, android.R
                .layout.simple_spinner_item, speedSelect);

        speedSpin.setAdapter(speedSpinnerAdapter);
    }

    @Override
    public void onBackPressed() {
        mBackPressed = true;
        onStop();
        finish();
        //super.onBackPressed();
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (mBackPressed || !mVideoView.isBackgroundPlayEnabled()) {
            mVideoView.stopPlayback();
            mVideoView.release(true);
            mVideoView.stopBackgroundPlay();
        } else {
            mVideoView.enterBackground();
        }
        IjkMediaPlayer.native_profileEnd();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_mark, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_toggle_ratio) {
            int aspectRatio = mVideoView.toggleAspectRatio();
            String aspectRatioText = MeasureHelper.getAspectRatioText(this, aspectRatio);
            mToastTextView.setText(aspectRatioText);
            mMediaController.showOnce(mToastTextView);
            return true;
        } else if (id == R.id.action_toggle_player) {
            int player = mVideoView.togglePlayer();
            String playerText = IjkVideoView.getPlayerText(this, player);
            mToastTextView.setText(playerText);
            mMediaController.showOnce(mToastTextView);
            return true;
        } else if (id == R.id.action_toggle_render) {
            int render = mVideoView.toggleRender();
            String renderText = IjkVideoView.getRenderText(this, render);
            mToastTextView.setText(renderText);
            mMediaController.showOnce(mToastTextView);
            return true;
        } else if (id == R.id.action_show_info) {
            mVideoView.showMediaInfo();
        } else if (id == R.id.action_show_tracks) {
            if (mDrawerLayout.isDrawerOpen(mRightDrawer)) {
                Fragment f = getSupportFragmentManager().findFragmentById(R.id.right_drawer);
                if (f != null) {
                    FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                    transaction.remove(f);
                    transaction.commit();
                }
                mDrawerLayout.closeDrawer(mRightDrawer);
            } else {
                Fragment f = TracksFragment.newInstance();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.right_drawer, f);
                transaction.commit();
                mDrawerLayout.openDrawer(mRightDrawer);
            }
        }

        if(id == R.id.finish_mark) {
            Intent intent = new Intent();
            intent.putExtra("markMatch", markMatch.getString());
            setResult(MARK_FINISHED, intent);
            mBackPressed = true;
            onStop();
            finish();
        } else if(id == R.id.preview_mark) {
            mVideoView.pause();
            Intent intent = EditorActivity.newIntent(mContext, markMatch.getString() );
            startActivityForResult(intent, MARK_UNFINISHED);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public ITrackInfo[] getTrackInfo() {
        if (mVideoView == null)
            return null;

        return mVideoView.getTrackInfo();
    }

    @Override
    public void selectTrack(int stream) {
        mVideoView.selectTrack(stream);
    }

    @Override
    public void deselectTrack(int stream) {
        mVideoView.deselectTrack(stream);
    }

    @Override
    public int getSelectedTrack(int trackType) {
        if (mVideoView == null)
            return -1;

        return mVideoView.getSelectedTrack(trackType);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == MARK_UNFINISHED) {
            mVideoView.start();
        }
    }
}

