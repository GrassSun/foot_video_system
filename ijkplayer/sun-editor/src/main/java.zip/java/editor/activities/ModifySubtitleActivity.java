package editor.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import editor.ijk.demo.R;
import editor.widget.SubtitleAdapter;
import markoperator.MarkMatch;
import markoperator.MarkSubTitle;

public class ModifySubtitleActivity extends AppCompatActivity {

    private MarkMatch match;

    public static Intent newIntent(Context context, MarkMatch markMatch) {
        Intent intent = new Intent(context, ModifySubtitleActivity.class);
        intent.putExtra("markMatch", markMatch.getString());
        return intent;
    }

    private ListView operateListView;
    private ListView infoListView;
    private ArrayList<MarkSubTitle> subTitleArrayList;
    private SubtitleAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_subtitle);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Demo");
        setSupportActionBar(toolbar);

        String markString = getIntent().getStringExtra("markMatch");
        try {
            JSONObject json = new JSONObject(markString);
            match = new MarkMatch(json);
        } catch (JSONException e) {
            e.printStackTrace();
            match = new MarkMatch();
        }

        operateListView = (ListView) findViewById(R.id.operate_list);
        infoListView = (ListView) findViewById(R.id.info_list);

        ArrayList<String> operator = new ArrayList<>();
        operator.add("Add");
        operator.add("Remove");
        operator.add("Finish");

        operateListView.setAdapter(new ArrayAdapter<String>(this, android.R.layout
                .simple_list_item_1, operator));

        operateListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if(position == 0) {
                    MarkSubTitle markSubTitle = new MarkSubTitle("", 0, 0);
                    Intent intent = SubtitleInputActivity.newIntent(getApplicationContext(),
                            markSubTitle);
                    startActivityForResult(intent, 1001);
                } else if(position == 1) {
                    int chosen = mAdapter.getChosen();
                    if(chosen == -1)
                        return;
                    /*if(position == 1) {

                    } else if(position == 2) {*/
                        MarkSubTitle markSub = (MarkSubTitle) mAdapter.getItem(chosen);
                        match.sub.remove(chosen);
                        mAdapter.remove(markSub);
                        mAdapter.setChose(-1);
                        mAdapter.notifyDataSetChanged();
                    }
                //}
                else if(position == 2) {
                    String markString = match.getString();
                    Intent intent = new Intent();
                    intent.putExtra("markMatch", markString);
                    setResult(1002, intent);
                    finish();
                }
            }
        });

        subTitleArrayList = new ArrayList<>();
        for(int i = 0; i < match.sub.size(); ++i) {
            MarkSubTitle sub = match.sub.get(i);
            MarkSubTitle newSub = new MarkSubTitle(sub.getText(), sub.getStart(), sub.getEnd());
            subTitleArrayList.add(newSub);
        }

        mAdapter= new SubtitleAdapter(this, R.layout.subtitle_item, subTitleArrayList);

        infoListView.setAdapter(mAdapter);
        infoListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                int chosen = mAdapter.getChosen();

                if(chosen == position) {
                    mAdapter.setChose(-1);
                    mAdapter.notifyDataSetChanged();
                    return;
                }

                mAdapter.setChose(position);
                mAdapter.notifyDataSetChanged();
            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == 1002) {
            String subString = data.getStringExtra("markSubtitle");
            MarkSubTitle sub;
            try {
                sub = new MarkSubTitle(new JSONObject(subString));
                if(sub.getStart() != -1 && sub.getEnd() != -1)
                    match.sub.add(sub);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        mAdapter.setChose(-1);
        while(mAdapter.getCount() != 0) {
            mAdapter.remove(mAdapter.getItem(0));
        }

        for(int i = 0; i < match.sub.size(); ++i) {
            MarkSubTitle sub = match.sub.get(i);
            MarkSubTitle newSub = new MarkSubTitle(sub.getText(), sub.getStart(), sub.getEnd());
            mAdapter.add(newSub);
        }
    }

}
