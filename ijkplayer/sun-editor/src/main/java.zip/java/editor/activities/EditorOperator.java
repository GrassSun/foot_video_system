package editor.activities;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import editor.ijk.demo.R;
import editor.widget.MatchAdapter;
import file.FileHelper;
import file.MySimpleTest;
import markoperator.MarkMatch;

public class EditorOperator extends AppCompatActivity {

    public static final int EDITING = 1001;
    public static final int OPERATE_OPEN = 0;
    public static final int OPERATE_NEW = OPERATE_OPEN + 1;
    public static final int OPERATE_MODIFY = OPERATE_NEW + 1;
    public static final int OPERATE_REMOVE = OPERATE_MODIFY + 1;
    public static final int OPERATE_MARK = OPERATE_REMOVE + 1;

    public static Intent newIntent(Context context) {
        Intent intent = new Intent(context, EditorOperator.class);
        return intent;
    }

    public static void intentTo(Context context) {
        context.startActivity(newIntent(context));
    }

    private FileHelper fileHelper;
    private ArrayList<MarkMatch> matchList;
    private MatchAdapter mAdapter;

    ArrayList<String> operator;

    private Dialog sourceSpinnerDialog;
    private Spinner sourceSpinner;

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor_operator);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Demo");
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);

        final Context mContext = getApplicationContext();
        fileHelper = FileHelper.getInstance(mContext);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Make test files!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                fileHelper.makeTestMarkMatch();
            }
        });

        ListView matchListView = (ListView) findViewById(R.id.match_list);
        ListView infoListView = (ListView) findViewById(R.id.info_list);

        matchList = fileHelper.getMatchList();
        mAdapter= new MatchAdapter(this, R.layout.match_item, matchList);

        operator = new ArrayList<>();
        operator.add("播放");
        operator.add("新建");
        operator.add("修改");
        operator.add("删除");
        matchListView.setAdapter(mAdapter);
        infoListView.setAdapter(new ArrayAdapter<String>(this, android.R.layout
                .simple_list_item_1, operator));

        matchListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int chosen = mAdapter.getChosen();
                if(position == chosen) {
                    mAdapter.setChose(-1);
                    mAdapter.notifyDataSetChanged();
                    return;
                }
                mAdapter.setChose(position);
                mAdapter.notifyDataSetChanged();
            }
        });

        infoListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String op = operator.get(position);
                int chosen = mAdapter.getChosen();

                if(position == OPERATE_OPEN) {

                    if(chosen == -1)
                        return;
                    MarkMatch match = (MarkMatch) mAdapter.getItem(chosen);
                    EditorActivity.intentTo(mContext, match);


                } else if(position == OPERATE_MODIFY) {

                    if(chosen == -1)
                        return;

                    MarkMatch markMatch = (MarkMatch) mAdapter.getItem(chosen);
                    Intent intent = EditingActivity.newIntent(getApplicationContext(), markMatch);
                    startActivityForResult(intent, EDITING);

                } else if(position == OPERATE_NEW) {
                    setSpinnerDialog();
                    sourceSpinnerDialog.show();
/*
                    MarkMatch markMatch = new MarkMatch();
                    markMatch.setVideoSource("match1");
                    Intent intent = EditingActivity.newIntent(getApplicationContext(), markMatch);
                    startActivityForResult(intent, EDITING);
*/
                } else if(position == OPERATE_REMOVE) {

                    if(chosen == -1)
                        return;

                    MarkMatch markMatch = (MarkMatch) mAdapter.getItem(chosen);

                    String title = markMatch.getName();

                    fileHelper.removeMatchFile(title);

                    mAdapter.setChose(-1);
                    mAdapter.remove(markMatch);
                    mAdapter.notifyDataSetChanged();

                }
            }
        });

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            //申请WRITE_EXTERNAL_STORAGE权限
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
    }


    private void setSpinnerDialog() {
        sourceSpinnerDialog = new Dialog(this, R.style.NormalDialogStyle);
        View view = View.inflate(this, R.layout.dialog_video_source_spinner, null);
        sourceSpinnerDialog.setContentView(view);
        sourceSpinner = (Spinner) view.findViewById(R.id.video_source_spinner);
        Button acceptButton = (Button) view.findViewById(R.id.accept_button);
        Button cancelButton = (Button) view.findViewById(R.id.cancel_button);

        FileHelper fileHelper = FileHelper.getInstance(getApplicationContext());

        final ArrayList<String> sourceList = fileHelper.getSourceList();

        ArrayAdapter<String> sourceSpinnerAdapter = new ArrayAdapter<String>(this, android.R.layout
                .simple_spinner_item, sourceList);
        sourceSpinner.setAdapter(sourceSpinnerAdapter);

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sourceSpinnerDialog.dismiss();
            }
        });

        acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = sourceSpinner.getSelectedItemPosition();
                MarkMatch markMatch = new MarkMatch();
                markMatch.setVideoSource(sourceList.get(position));
                sourceSpinnerDialog.dismiss();
            }
        });

        sourceSpinnerDialog.hide();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        mAdapter.setChose(-1);
        mAdapter.clear();

        ArrayList<MarkMatch> matchList = fileHelper.getMatchList();
        for(int i = 0; i < matchList.size(); ++i)
            mAdapter.add(matchList.get(i));
    }

}
