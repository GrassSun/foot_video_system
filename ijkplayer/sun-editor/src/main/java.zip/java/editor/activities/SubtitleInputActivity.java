package editor.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import editor.ijk.demo.R;
import markoperator.MarkSubTitle;

public class SubtitleInputActivity extends AppCompatActivity {

    public static Intent newIntent(Context context, MarkSubTitle markSubTitle) {
        Intent intent = new Intent(context, SubtitleInputActivity.class);
        String subString = markSubTitle.getJson().toString();
        intent.putExtra("markSubTitle", subString);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subtitle_input);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Demo");
        setSupportActionBar(toolbar);
        setResult(0);
        final EditText subText = (EditText) findViewById(R.id.subtitle_info_value);
        final EditText startText = (EditText) findViewById(R.id.subtitle_start_time_info);
        final EditText endText = (EditText) findViewById(R.id.subtitle_end_time_info);

        Button clickButton = (Button) findViewById(R.id.add_subtitle);
        clickButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();

                String text = subText.getText().toString();
                String st = startText.getText().toString();
                String ed = endText.getText().toString();

                long start = -1;
                long end = -1;
                if(!st.equals(""))
                    start = (long) (Double.valueOf(st) * 1000);
                if(!ed.equals(""))
                    end = (long) (Double.valueOf(ed) * 1000);


                MarkSubTitle markSub = new MarkSubTitle(text, start, end);
                String subString = markSub.getJson().toString();
                intent.putExtra("markSubtitle", subString);
                setResult(1002, intent);
                finish();
            }
        });

    }

}
